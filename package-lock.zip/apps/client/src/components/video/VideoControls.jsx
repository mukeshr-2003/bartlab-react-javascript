// apps/client/src/components/video/VideoControls.jsx
import React, { useState } from "react";

const VideoControls = ({ localStream, onEndCall }) => {
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);

  const toggleMic = () => {
    if (!localStream) return;
    localStream.getAudioTracks().forEach((track) => {
      track.enabled = !track.enabled;
      setMicOn(track.enabled);
    });
  };

  const toggleCam = () => {
    if (!localStream) return;
    localStream.getVideoTracks().forEach((track) => {
      track.enabled = !track.enabled;
      setCamOn(track.enabled);
    });
  };

  return (
    <div className="video-controls">
      <button className="btn-outline" onClick={toggleMic}>
        {micOn ? "Mute" : "Unmute"}
      </button>
      <button className="btn-outline" onClick={toggleCam}>
        {camOn ? "Stop Video" : "Start Video"}
      </button>
      <button className="btn-end" onClick={onEndCall}>
        End Call
      </button>
    </div>
  );
};

export default VideoControls;
