// apps/client/src/components/video/VideoGrid.jsx
import React, { useEffect, useRef } from "react";

const Video = ({ stream, muted }) => {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current && stream) {
      ref.current.srcObject = stream;
    }
  }, [stream]);

  if (!stream) return null;

  return <video ref={ref} autoPlay playsInline muted={muted} />;
};

const VideoGrid = ({ localStream, remoteStreams }) => {
  const remote = remoteStreams.remote;

  return (
    <div className="video-grid">
      <div className="video-tile">
        <div className="video-label">You</div>
        <Video stream={localStream} muted={true} />
      </div>
      {remote && (
        <div className="video-tile">
          <div className="video-label">Remote</div>
          <Video stream={remote} muted={false} />
        </div>
      )}
    </div>
  );
};

export default VideoGrid;
