// apps/client/src/components/chat/MessageBubble.jsx
import React from "react";
import { useSelector } from "react-redux";

const MessageBubble = ({ message }) => {
  const { user } = useSelector((state) => state.auth);
  const isMine = message.sender?._id === user?._id;

  // Advanced tick logic
  let statusSymbol = "";
  let statusClass = "";

  if (isMine) {
    const deliveredCount = message.deliveredTo?.length || 0;
    const readCount = message.readBy?.length || 0;

    if (readCount > 0) {
      // ✅✅ blue – read by at least 1 person
      statusSymbol = "✓✓";
      statusClass = "msg-status msg-status--read";
    } else if (deliveredCount > 0) {
      // ✅✅ gray – delivered to at least 1 device
      statusSymbol = "✓✓";
      statusClass = "msg-status msg-status--delivered";
    } else {
      // ✅ – sent but not yet confirmed delivered
      statusSymbol = "✓";
      statusClass = "msg-status msg-status--sent";
    }
  }

  return (
    <div className={`msg-row ${isMine ? "msg-row--mine" : ""}`}>
      <div className={`msg-bubble ${isMine ? "msg-bubble--mine" : ""}`}>
        {!isMine && (
          <div className="msg-sender">{message.sender?.name || "User"}</div>
        )}
        {message.text && <div className="msg-text">{message.text}</div>}
        <div className="msg-meta">
          <span>
            {new Date(message.createdAt).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
          {isMine && statusSymbol && (
            <span className={statusClass} title={
              message.readBy?.length
                ? `Read by ${message.readBy.length} user(s)`
                : message.deliveredTo?.length
                ? `Delivered to ${message.deliveredTo.length} user(s)`
                : "Sent"
            }>
              {statusSymbol}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;

