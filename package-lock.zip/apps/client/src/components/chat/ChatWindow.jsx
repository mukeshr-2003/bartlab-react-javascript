// apps/client/src/components/chat/ChatWindow.jsx
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  addMessage,
  setMessagesForChat,
} from "../../store/chatSlice.js";
import {
  getMessagesByChatApi,
  sendMessageApi,
} from "../../services/chat.api.js";
import { useSocket } from "../../hooks/useSocket.js";
import MessageBubble from "./MessageBubble.jsx";
import { useNavigate } from "react-router-dom";

const ChatWindow = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { socket } = useSocket();
  const { activeChatId, messagesByChat, chats } = useSelector(
    (state) => state.chat
  );
  const { user } = useSelector((state) => state.auth);

  const [messageText, setMessageText] = useState("");
  const [typingUsers, setTypingUsers] = useState({});
  const messagesEndRef = useRef(null);

  const messages = activeChatId ? messagesByChat[activeChatId] || [] : [];

  // Load messages when activeChat changes
  useEffect(() => {
    const fetchMessages = async () => {
      if (!activeChatId) return;
      const data = await getMessagesByChatApi(activeChatId);
      dispatch(setMessagesForChat({ chatId: activeChatId, messages: data }));
    };
    fetchMessages();
  }, [activeChatId, dispatch]);

  // Join chat room via socket
  useEffect(() => {
    if (!socket || !activeChatId) return;
    socket.emit("chat:join", { chatId: activeChatId });

    socket.on("chat:new-message", (payload) => {
      if (payload.chatId === activeChatId) {
        dispatch(addMessage({ chatId: payload.chatId, message: payload.message }));
      }
    });

    socket.on("typing:start", ({ chatId, userId }) => {
      if (chatId !== activeChatId || userId === user._id) return;
      setTypingUsers((prev) => ({ ...prev, [userId]: true }));
    });

    socket.on("typing:stop", ({ chatId, userId }) => {
      if (chatId !== activeChatId || userId === user._id) return;
      setTypingUsers((prev) => {
        const copy = { ...prev };
        delete copy[userId];
        return copy;
      });
    });

    return () => {
      socket.emit("chat:leave", { chatId: activeChatId });
      socket.off("chat:new-message");
      socket.off("typing:start");
      socket.off("typing:stop");
    };
  }, [socket, activeChatId, dispatch, user?._id]);

  // Scroll to bottom when messages update
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length]);

  if (!activeChatId) {
    return (
      <div className="chat-window-empty">
        <p>Select a chat to start messaging</p>
      </div>
    );
  }

  const activeChat = chats.find((c) => c._id === activeChatId);
  const title =
    activeChat?.isGroup && activeChat?.name
      ? activeChat.name
      : (activeChat?.members || []).map((m) => m.name).join(", ");

  const handleSend = async (e) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    const text = messageText.trim();
    setMessageText("");

    const msg = await sendMessageApi({
      chatId: activeChatId,
      text,
    });

    // Add to state
    dispatch(addMessage({ chatId: activeChatId, message: msg }));

    // Emit socket event
    if (socket) {
      socket.emit("chat:send-message", {
        chatId: activeChatId,
        message: msg,
      });
      socket.emit("typing:stop", { chatId: activeChatId, userId: user._id });
    }
  };

  const handleTyping = (value) => {
    setMessageText(value);
    if (!socket) return;
    if (value) {
      socket.emit("typing:start", { chatId: activeChatId, userId: user._id });
    } else {
      socket.emit("typing:stop", { chatId: activeChatId, userId: user._id });
    }
  };

  const handleStartCall = () => {
    navigate(`/call/${activeChatId}`);
  };

  const typingCount = Object.keys(typingUsers).length;

  return (
    <div className="chat-window">
      <div className="chat-window-header">
        <div>
          <div className="chat-window-title">{title}</div>
          {typingCount > 0 && (
            <div className="chat-window-typing">
              Someone is typing...
            </div>
          )}
        </div>
        <button className="btn-outline" onClick={handleStartCall}>
          Start Call
        </button>
      </div>

      <div className="chat-window-messages">
        {messages.map((m) => (
          <MessageBubble key={m._id} message={m} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form className="chat-window-input" onSubmit={handleSend}>
        <input
          type="text"
          placeholder="Type your message..."
          value={messageText}
          onChange={(e) => handleTyping(e.target.value)}
        />
        <button type="submit" className="btn-outline">
          Send
        </button>
      </form>
    </div>
  );
};

export default ChatWindow;
