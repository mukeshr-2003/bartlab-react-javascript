// apps/client/src/components/chat/ChatList.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  setActiveChat,
  setChatError,
  setChatStatus,
  setChats,
} from "../../store/chatSlice.js";
import {
  getMyChatsApi,
  createGroupChatApi,
} from "../../services/chat.api.js";
import Modal from "../common/Modal.jsx";

const ChatList = () => {
  const dispatch = useDispatch();
  const { chats, activeChatId, status, error } = useSelector(
    (state) => state.chat
  );
  const { user } = useSelector((state) => state.auth);

  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [chatName, setChatName] = useState("");

  // load chats on mount
  useEffect(() => {
    const fetchChats = async () => {
      try {
        dispatch(setChatStatus("loading"));
        const data = await getMyChatsApi();
        dispatch(setChats(data));
        dispatch(setChatStatus("succeeded"));
      } catch (err) {
        dispatch(
          setChatError(err.response?.data?.message || "Failed to load chats")
        );
      }
    };
    fetchChats();
  }, [dispatch]);

  const handleSelectChat = (chatId) => {
    dispatch(setActiveChat(chatId));
  };

  const openModal = () => {
    setChatName("");
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleCreateChat = async (e) => {
    e.preventDefault();
    if (!chatName.trim()) return;

    try {
      dispatch(setChatStatus("loading"));

      // For now, create a small "personal group" (only you).
      const chat = await createGroupChatApi(chatName.trim(), []);

      // Reload chats from server to keep everything in sync
      const data = await getMyChatsApi();
      dispatch(setChats(data));
      dispatch(setActiveChat(chat._id));
      dispatch(setChatStatus("succeeded"));
      setIsModalOpen(false);
    } catch (err) {
      dispatch(
        setChatError(err.response?.data?.message || "Failed to create chat")
      );
    }
  };

  const filteredChats = useMemo(() => {
    if (!search.trim()) return chats;

    const q = search.toLowerCase();
    return chats.filter((chat) => {
      const title =
        chat.isGroup && chat.name
          ? chat.name
          : (chat.members || [])
              .filter((m) => m._id !== user?._id)
              .map((m) => m.name)
              .join(", ") || "Direct Chat";

      const lastText = chat.lastMessage?.text || "";
      return (
        title.toLowerCase().includes(q) || lastText.toLowerCase().includes(q)
      );
    });
  }, [chats, search, user?._id]);

  const formatTime = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <>
      <div className="chat-list">
        <div className="chat-list-header">
          <h3>Chats</h3>
          <button className="btn-outline" onClick={openModal}>
            + New Chat
          </button>
        </div>

        <div className="chat-list-search">
          <input
            type="text"
            placeholder="Search chats..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="chat-list-body">
          {status === "loading" && <div>Loading chats...</div>}

          {error && (
            <div className="chat-list-error">
              {error}
            </div>
          )}

          {filteredChats.map((chat) => {
            const title =
              chat.isGroup && chat.name
                ? chat.name
                : (chat.members || [])
                    .filter((m) => m._id !== user?._id)
                    .map((m) => m.name)
                    .join(", ") || "Direct Chat";

            const lastText = chat.lastMessage?.text || "No messages yet";

            return (
              <button
                key={chat._id}
                className={
                  "chat-list-item" +
                  (activeChatId === chat._id ? " chat-list-item--active" : "")
                }
                onClick={() => handleSelectChat(chat._id)}
              >
                <div className="chat-list-item-row">
                  <div className="chat-list-title">{title}</div>
                  <div className="chat-list-time">
                    {formatTime(chat.updatedAt)}
                  </div>
                </div>
                <div className="chat-list-last">
                  {lastText.length > 40
                    ? lastText.slice(0, 40) + "..."
                    : lastText}
                </div>
              </button>
            );
          })}

          {status === "succeeded" && filteredChats.length === 0 && (
            <div className="chat-list-empty">
              No chats found. Create a new one using the button above.
            </div>
          )}
        </div>
      </div>

      <Modal open={isModalOpen} onClose={closeModal} title="Create New Chat">
        <form onSubmit={handleCreateChat} className="chat-modal-form">
          <input
            type="text"
            placeholder="Chat name (e.g., Project Team)"
            value={chatName}
            onChange={(e) => setChatName(e.target.value)}
            required
          />
          <button type="submit" className="btn-outline">
            Create
          </button>
        </form>
        <p className="chat-modal-hint">
          This will create a private chat for now.  
          Later you can extend it to add members, like a full group chat.
        </p>
      </Modal>
    </>
  );
};

export default ChatList;
