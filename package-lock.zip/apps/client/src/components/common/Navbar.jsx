// apps/client/src/components/common/Navbar.jsx
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../store/authSlice.js";
import { useNavigate } from "react-router-dom";
import { toggleTheme } from "../../store/themeSlice.js";

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);
  const { mode } = useSelector((state) => state.theme);

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  return (
    <header className="navbar">
      <div className="navbar-left" onClick={() => navigate("/chats")}>
        <span className="logo">Realtime Chat</span>
      </div>
      <div className="navbar-right">
        <button
          className="btn-ghost"
          title="Toggle theme"
          onClick={() => dispatch(toggleTheme())}
        >
          {mode === "dark" ? "🌙" : "☀️"}
        </button>
        {user && (
          <>
            <span className="navbar-user">{user.name}</span>
            <button className="btn-outline" onClick={handleLogout}>
              Logout
            </button>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
