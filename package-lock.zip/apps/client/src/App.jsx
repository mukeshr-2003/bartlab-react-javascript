// apps/client/src/App.jsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/common/Navbar.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import ChatPage from "./pages/ChatPage.jsx";
import CallPage from "./pages/CallPage.jsx";
import { useSelector } from "react-redux";

function App() {
  const { user } = useSelector((state) => state.auth);

  return (
    <div className="app-root">
      {user && <Navbar />}
      <Routes>
        <Route
          path="/"
          element={
            user ? <Navigate to="/chats" replace /> : <Navigate to="/login" replace />
          }
        />
        <Route
          path="/login"
          element={user ? <Navigate to="/chats" replace /> : <Login />}
        />
        <Route
          path="/signup"
          element={user ? <Navigate to="/chats" replace /> : <Signup />}
        />
        <Route
          path="/chats"
          element={user ? <ChatPage /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/call/:chatId"
          element={user ? <CallPage /> : <Navigate to="/login" replace />}
        />
        <Route path="*" element={<div>404 | Page not found</div>} />
      </Routes>
    </div>
  );
}

export default App;
