// apps/client/src/store/chatSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  chats: [],
  activeChatId: null,
  messagesByChat: {}, // { [chatId]: [messages] }
  status: "idle",
  error: null,
};

const chatSlice = createSlice({
  name: "chat",
  initialState,
  reducers: {
    setChats(state, action) {
      state.chats = action.payload || [];
      state.status = "succeeded";
    },
    setChatStatus(state, action) {
      state.status = action.payload;
    },
    setChatError(state, action) {
      state.error = action.payload;
      state.status = "failed";
    },
    setActiveChat(state, action) {
      state.activeChatId = action.payload;
    },
    setMessagesForChat(state, action) {
      const { chatId, messages } = action.payload;
      state.messagesByChat[chatId] = messages;
    },
    addMessage(state, action) {
      const { chatId, message } = action.payload;
      if (!state.messagesByChat[chatId]) {
        state.messagesByChat[chatId] = [];
      }
      state.messagesByChat[chatId].push(message);
    },
    prependMessages(state, action) {
      const { chatId, messages } = action.payload;
      const existing = state.messagesByChat[chatId] || [];
      state.messagesByChat[chatId] = [...messages, ...existing];
    },
  },
});

export const {
  setChats,
  setChatStatus,
  setChatError,
  setActiveChat,
  setMessagesForChat,
  addMessage,
  prependMessages,
} = chatSlice.actions;

export default chatSlice.reducer;
