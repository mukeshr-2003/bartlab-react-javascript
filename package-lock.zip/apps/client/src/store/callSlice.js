// apps/client/src/store/callSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  inCall: false,
  roomId: null,
  chatId: null,
  type: null, // "audio" | "video"
};

const callSlice = createSlice({
  name: "call",
  initialState,
  reducers: {
    startCall(state, action) {
      const { roomId, chatId, type } = action.payload;
      state.inCall = true;
      state.roomId = roomId;
      state.chatId = chatId || null;
      state.type = type || "video";
    },
    endCall(state) {
      state.inCall = false;
      state.roomId = null;
      state.chatId = null;
      state.type = null;
    },
  },
});

export const { startCall, endCall } = callSlice.actions;
export default callSlice.reducer;
