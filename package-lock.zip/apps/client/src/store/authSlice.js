// apps/client/src/store/authSlice.js
import { createSlice } from "@reduxjs/toolkit";

const storedUser = localStorage.getItem("user");
const storedToken = localStorage.getItem("token");

const initialState = {
  user: storedUser ? JSON.parse(storedUser) : null,
  token: storedToken || null,
  status: "idle",
  error: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setAuthPending(state) {
      state.status = "loading";
      state.error = null;
    },
    setAuthSuccess(state, action) {
      state.status = "succeeded";
      state.error = null;
      state.user = action.payload.user;
      state.token = action.payload.token;

      localStorage.setItem("user", JSON.stringify(action.payload.user));
      localStorage.setItem("token", action.payload.token);
    },
    setAuthError(state, action) {
      state.status = "failed";
      state.error = action.payload || "Authentication failed";
    },
    logout(state) {
      state.user = null;
      state.token = null;
      state.status = "idle";
      state.error = null;
      localStorage.removeItem("user");
      localStorage.removeItem("token");
    },
  },
});

export const { setAuthPending, setAuthSuccess, setAuthError, logout } =
  authSlice.actions;

export default authSlice.reducer;
