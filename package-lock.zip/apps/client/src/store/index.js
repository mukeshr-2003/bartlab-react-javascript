// apps/client/src/store/index.js
import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./authSlice.js";
import chatReducer from "./chatSlice.js";
import callReducer from "./callSlice.js";
import themeReducer from "./themeSlice.js";

const store = configureStore({
  reducer: {
    auth: authReducer,
    chat: chatReducer,
    call: callReducer,
    theme: themeReducer,
  },
});

export default store;
