// apps/client/src/store/themeSlice.js
import { createSlice } from "@reduxjs/toolkit";

const storedMode = localStorage.getItem("themeMode");

const initialState = {
  mode: storedMode || "dark",
};

const themeSlice = createSlice({
  name: "theme",
  initialState,
  reducers: {
    toggleTheme(state) {
      state.mode = state.mode === "dark" ? "light" : "dark";
      localStorage.setItem("themeMode", state.mode);
    },
    setTheme(state, action) {
      state.mode = action.payload;
      localStorage.setItem("themeMode", state.mode);
    },
  },
});

export const { toggleTheme, setTheme } = themeSlice.actions;
export default themeSlice.reducer;
