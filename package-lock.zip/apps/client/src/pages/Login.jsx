// apps/client/src/pages/Login.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.js";

const inputStyle = {
  padding: "10px 15px",
  borderRadius: "10px",
  background: "#e5edff",
  border: "none",
  marginBottom: "12px",
  fontSize: "0.95rem",
};

export default function Login() {
  const navigate = useNavigate();
  const { login, status, error } = useAuth();

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
  });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await login(form.email, form.password);
      navigate("/");
    } catch (_) {}
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#0f1624",
      }}
    >
      {/* ✅ Logo from public/logo.png, centered */}
      <div style={{ display: "flex", justifyContent: "center", width: "100%" }}>
        <img
          src="/logo.png"
          alt="App Logo"
          style={{
            width: 100,
            height: 100,
            marginBottom: 20,
            opacity: 0.95,
            userSelect: "none",
          }}
        />
      </div>

      <div
        style={{
          width: "380px",
          maxWidth: "90%",
          background: "#111827",
          padding: "35px",
          borderRadius: "14px",
          boxShadow: "0px 0px 15px rgba(0,0,0,0.3)",
          color: "white",
          textAlign: "center",
        }}
      >
        <h2 style={{ marginBottom: "20px", fontSize: "1.8rem" }}>Login</h2>

        {error && (
          <div
            style={{
              marginBottom: "10px",
              color: "#f97373",
              fontSize: "0.85rem",
            }}
          >
            {error}
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column" }}
        >
          <input
            type="text"
            name="fullName"
            placeholder="Full Name"
            value={form.fullName}
            onChange={handleChange}
            style={inputStyle}
          />

          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={form.email}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <button
            disabled={status === "loading"}
            type="submit"
            style={{
              marginTop: "16px",
              padding: "10px 0",
              borderRadius: "10px",
              backgroundColor: status === "loading" ? "#1f2a37" : "#1d4ed8",
              cursor: status === "loading" ? "not-allowed" : "pointer",
              color: "white",
              border: "none",
              fontSize: "1rem",
              transition: "0.25s",
            }}
          >
            {status === "loading" ? "Logging in..." : "Login"}
          </button>
        </form>

        <p
          style={{ marginTop: "16px", fontSize: "0.9rem", color: "#cbd5e1" }}
        >
          Don&apos;t have an account?{" "}
          <Link
            to="/signup"
            style={{ color: "#60a5fa", textDecoration: "underline" }}
          >
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}

