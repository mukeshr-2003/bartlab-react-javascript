// apps/client/src/pages/ChatPage.jsx
import React from "react";
import ChatList from "../components/chat/ChatList.jsx";
import ChatWindow from "../components/chat/ChatWindow.jsx";

const ChatPage = () => {
  return (
    <div className="chat-page">
      <ChatList />
      <ChatWindow />
    </div>
  );
};

export default ChatPage;
