// apps/client/src/pages/Signup.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.js";

const inputStyle = {
  padding: "10px 15px",
  borderRadius: "10px",
  background: "#e5edff",
  border: "none",
  marginBottom: "12px",
  fontSize: "0.95rem",
};

export default function Signup() {
  const navigate = useNavigate();
  const { signup, status, error } = useAuth();

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    mobile: "",
    password: "",
    confirmPassword: "",
  });

  const [localError, setLocalError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLocalError("");

    if (form.password !== form.confirmPassword) {
      setLocalError("Passwords do not match");
      return;
    }

    if (!form.mobile || form.mobile.length < 8) {
      setLocalError("Please enter a valid mobile number");
      return;
    }

    try {
      await signup(form.fullName, form.email, form.password, form.mobile);
      navigate("/");
    } catch (_) {
      // error handled by hook
    }
  };

  const finalError = localError || error;

  return (
    <div
      className="signup-wrapper"
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#0f1624",
      }}
    >
      {/* ✅ Centered logo */}
      <div style={{ display: "flex", justifyContent: "center", width: "100%" }}>
        <img
          src="/logo.png"
          alt="App Logo"
          style={{
            width: 100,
            height: 100,
            marginBottom: 20,
            opacity: 0.95,
            userSelect: "none",
          }}
        />
      </div>

      {/* Signup card */}
      <div
        style={{
          width: "400px",
          maxWidth: "90%",
          background: "#111827",
          padding: "35px",
          borderRadius: "14px",
          boxShadow: "0px 0px 15px rgba(0,0,0,0.3)",
          color: "white",
          textAlign: "center",
        }}
      >
        <h2 style={{ marginBottom: "20px", fontSize: "1.8rem" }}>Sign Up</h2>

        {finalError && (
          <div
            style={{
              marginBottom: "10px",
              color: "#f97373",
              fontSize: "0.85rem",
            }}
          >
            {finalError}
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column" }}
        >
          <input
            type="text"
            name="fullName"
            placeholder="Full Name"
            value={form.fullName}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={form.email}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <input
            type="tel"
            name="mobile"
            placeholder="Mobile Number"
            value={form.mobile}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <input
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            value={form.confirmPassword}
            onChange={handleChange}
            style={inputStyle}
            required
          />

          <button
            disabled={status === "loading"}
            type="submit"
            style={{
              marginTop: "16px",
              padding: "10px 0",
              borderRadius: "10px",
              backgroundColor: status === "loading" ? "#1f2a37" : "#16a34a",
              cursor: status === "loading" ? "not-allowed" : "pointer",
              color: "white",
              border: "none",
              fontSize: "1rem",
              transition: "0.25s",
            }}
          >
            {status === "loading" ? "Creating account..." : "Sign Up"}
          </button>
        </form>

        <p
          style={{ marginTop: "16px", fontSize: "0.9rem", color: "#cbd5e1" }}
        >
          Already have an account?{" "}
          <Link
            to="/login"
            style={{ color: "#60a5fa", textDecoration: "underline" }}
          >
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
