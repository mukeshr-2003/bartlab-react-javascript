// apps/client/src/pages/CallPage.jsx
import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useWebRTC } from "../hooks/useWebRTC.js";
import VideoGrid from "../components/video/VideoGrid.jsx";
import VideoControls from "../components/video/VideoControls.jsx";
import { useSocket } from "../hooks/useSocket.js";

const CallPage = () => {
  const { chatId } = useParams();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);
  const { socket } = useSocket();
  const { localStream, remoteStreams, initLocalStream } = useWebRTC(
    chatId,
    user?._id
  );

  useEffect(() => {
    (async () => {
      await initLocalStream();
    })();
  }, [initLocalStream]);

  const handleEndCall = () => {
    if (socket) {
      socket.emit("call:end", { roomId: chatId, userId: user._id });
    }
    navigate("/chats");
  };

  return (
    <div className="call-page">
      <VideoGrid localStream={localStream} remoteStreams={remoteStreams} />
      <VideoControls localStream={localStream} onEndCall={handleEndCall} />
    </div>
  );
};

export default CallPage;
