// apps/client/src/hooks/useWebRTC.js
import { useEffect, useRef, useState, useCallback } from "react";
import { useSocket } from "./useSocket.js";

const RTC_CONFIG = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    // Add TURN here in production
  ],
};

export const useWebRTC = (roomId, currentUserId) => {
  const { socket } = useSocket();
  const [remoteStreams, setRemoteStreams] = useState({});
  const [localStream, setLocalStream] = useState(null);

  const peerConnectionRef = useRef(null);

  // Get user media
  const initLocalStream = useCallback(async () => {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });
    setLocalStream(stream);
    return stream;
  }, []);

  const createPeerConnection = useCallback(
    (stream) => {
      const pc = new RTCPeerConnection(RTC_CONFIG);

      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });

      pc.ontrack = (event) => {
        const [remoteStream] = event.streams;
        setRemoteStreams((prev) => ({
          ...prev,
          remote: remoteStream,
        }));
      };

      pc.onicecandidate = (event) => {
        if (event.candidate && socket && roomId) {
          socket.emit("call:ice-candidate", {
            roomId,
            candidate: event.candidate,
            fromUserId: currentUserId,
          });
        }
      };

      peerConnectionRef.current = pc;
      return pc;
    },
    [socket, roomId, currentUserId]
  );

  // Join room and setup listeners
  useEffect(() => {
    if (!socket || !roomId || !currentUserId) return;

    socket.emit("call:join", { roomId, userId: currentUserId });

    socket.on("call:user-joined", () => {
      // We can initiate offer when someone joins
      (async () => {
        const stream = localStream || (await initLocalStream());
        const pc = peerConnectionRef.current || createPeerConnection(stream);

        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        socket.emit("call:offer", {
          roomId,
          offer,
          fromUserId: currentUserId,
        });
      })();
    });

    socket.on("call:offer", async ({ offer, fromUserId }) => {
      const stream = localStream || (await initLocalStream());
      const pc = peerConnectionRef.current || createPeerConnection(stream);

      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      socket.emit("call:answer", {
        roomId,
        answer,
        fromUserId: currentUserId,
      });
    });

    socket.on("call:answer", async ({ answer }) => {
      const pc = peerConnectionRef.current;
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
      }
    });

    socket.on("call:ice-candidate", async ({ candidate }) => {
      const pc = peerConnectionRef.current;
      if (pc && candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.error("Error adding ICE candidate", err);
        }
      }
    });

    socket.on("call:end", () => {
      endCall();
    });

    const endCall = () => {
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }
      if (localStream) {
        localStream.getTracks().forEach((t) => t.stop());
      }
      setLocalStream(null);
      setRemoteStreams({});
    };

    return () => {
      socket.emit("call:leave", { roomId, userId: currentUserId });
      socket.off("call:user-joined");
      socket.off("call:offer");
      socket.off("call:answer");
      socket.off("call:ice-candidate");
      socket.off("call:end");
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }
    };
  }, [
    socket,
    roomId,
    currentUserId,
    initLocalStream,
    createPeerConnection,
    localStream,
  ]);

  return {
    localStream,
    remoteStreams,
    initLocalStream,
  };
};
