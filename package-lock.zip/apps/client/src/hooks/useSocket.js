// apps/client/src/hooks/useSocket.js
import { useEffect, useRef } from "react";
import { io } from "socket.io-client";
import { useSelector } from "react-redux";

const SOCKET_URL =
  import.meta.env.VITE_SOCKET_URL || "http://localhost:5000";

let socketSingleton = null;

export const useSocket = () => {
  const { token, user } = useSelector((state) => state.auth);
  const socketRef = useRef(null);

  useEffect(() => {
    if (!token || !user) return;

    if (!socketSingleton) {
      socketSingleton = io(SOCKET_URL, {
        auth: { token },
      });
    }

    socketRef.current = socketSingleton;

    // Notify presence
    socketSingleton.emit("user:online", { userId: user._id });

    return () => {
      // We DON'T disconnect singleton on unmount – only on logout
    };
  }, [token, user]);

  // Helper to disconnect manually (e.g., on logout)
  const disconnect = () => {
    if (socketSingleton) {
      socketSingleton.emit("user:offline", { userId: user?._id });
      socketSingleton.disconnect();
      socketSingleton = null;
      socketRef.current = null;
    }
  };

  return { socket: socketRef.current, disconnect };
};
