// apps/client/src/hooks/useAuth.js
import { useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  setAuthPending,
  setAuthSuccess,
  setAuthError,
  logout as logoutAction,
} from "../store/authSlice.js";
import { loginApi, signupApi, getMeApi } from "../services/auth.api.js";

export const useAuth = () => {
  const dispatch = useDispatch();
  const authState = useSelector((state) => state.auth);

  const login = useCallback(
    async (email, password) => {
      try {
        dispatch(setAuthPending());
        const data = await loginApi(email, password);
        dispatch(setAuthSuccess({ user: data.user, token: data.token }));
        return data;
      } catch (err) {
        dispatch(setAuthError(err.response?.data?.message || err.message));
        throw err;
      }
    },
    [dispatch]
  );

  const signup = useCallback(
    async (name, email, password) => {
      try {
        dispatch(setAuthPending());
        const data = await signupApi(name, email, password);
        dispatch(setAuthSuccess({ user: data.user, token: data.token }));
        return data;
      } catch (err) {
        dispatch(setAuthError(err.response?.data?.message || err.message));
        throw err;
      }
    },
    [dispatch]
  );

  const fetchMe = useCallback(async () => {
    try {
      const data = await getMeApi();
      dispatch(
        setAuthSuccess({
          user: data.user,
          token: localStorage.getItem("token"),
        })
      );
      return data.user;
    } catch (err) {
      // token invalid – logout silently
      dispatch(logoutAction());
      throw err;
    }
  }, [dispatch]);

  const logout = useCallback(() => {
    dispatch(logoutAction());
  }, [dispatch]);

  return {
    ...authState,
    login,
    signup,
    fetchMe,
    logout,
  };
};
