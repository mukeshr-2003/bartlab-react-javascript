// apps/client/src/hooks/useNotifications.js
import { useCallback } from "react";

export const useNotifications = () => {
  const requestPermission = useCallback(async () => {
    if (!("Notification" in window)) return false;
    if (Notification.permission === "granted") return true;
    const res = await Notification.requestPermission();
    return res === "granted";
  }, []);

  const showNotification = useCallback(
    async ({ title, body }) => {
      if (!("Notification" in window)) {
        alert(`${title}\n\n${body}`);
        return;
      }

      const allowed = await requestPermission();
      if (!allowed) return;

      new Notification(title, {
        body,
      });
    },
    [requestPermission]
  );

  return {
    requestPermission,
    showNotification,
  };
};
