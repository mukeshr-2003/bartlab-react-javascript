// apps/client/src/hooks/useEncryption.js

// NOTE: This is a SIMPLE placeholder using base64.
// For real encryption, sync with your backend /common package.
const encode = (text) => window.btoa(unescape(encodeURIComponent(text)));
const decode = (text) => decodeURIComponent(escape(window.atob(text)));

export const useEncryption = () => {
  const encryptText = (plain) => {
    if (!plain) return "";
    return encode(plain);
  };

  const decryptText = (cipher) => {
    if (!cipher) return "";
    try {
      return decode(cipher);
    } catch {
      return cipher;
    }
  };

  return { encryptText, decryptText };
};
