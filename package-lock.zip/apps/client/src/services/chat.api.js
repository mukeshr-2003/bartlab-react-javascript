// apps/client/src/services/chat.api.js
import api from "./api.js";

export const getMyChatsApi = async () => {
  const res = await api.get("/chats");
  return res.data.chats;
};

export const createOrGetOneToOneChatApi = async (memberId) => {
  const res = await api.post("/chats", { memberId });
  return res.data.chat;
};

export const createGroupChatApi = async (name, memberIds) => {
  const res = await api.post("/chats/group", { name, memberIds });
  return res.data.chat;
};

export const getMessagesByChatApi = async (chatId) => {
  const res = await api.get(`/messages/${chatId}`);
  return res.data.messages;
};

export const sendMessageApi = async ({ chatId, text, attachments }) => {
  const res = await api.post("/messages", {
    chatId,
    text,
    attachments,
  });
  return res.data.data; // message
};

export const markMessagesAsReadApi = async ({ chatId, messageIds }) => {
  const res = await api.post(`/messages/${chatId}/read`, {
    messageIds,
  });
  return res.data;
};
