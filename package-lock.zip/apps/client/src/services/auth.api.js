// apps/client/src/services/auth.api.js
import api from "./api.js";

export const loginApi = async (email, password) => {
  const res = await api.post("/auth/login", { email, password });
  return res.data; // { message, user, token }
};

export const signupApi = async (name, email, password) => {
  const res = await api.post("/auth/signup", { name, email, password });
  return res.data; // { message, user, token }
};

export const getMeApi = async () => {
  const res = await api.get("/auth/me");
  return res.data; // { user }
};
