// apps/client/src/services/upload.api.js
import api from "./api.js";

/**
 * Upload file to server (expects a backend /api/upload route).
 * Usage:
 *   const formData = new FormData();
 *   formData.append("file", file);
 *   const res = await uploadFileApi(formData);
 */
export const uploadFileApi = async (formData) => {
  const res = await api.post("/upload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data; // Expect { url, key } etc.
};
