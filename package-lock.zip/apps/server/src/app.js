// apps/server/src/app.js
import express from "express";
import cors from "cors";
import routes from "./routes/index.js";
import { errorHandler } from "./utils/error.js";
import { env } from "./config/env.js";

const app = express();

// CORS
const allowedOrigins = [env.CLIENT_URL, env.ADMIN_URL].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow mobile apps / Postman / same-origin
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error("Not allowed by CORS"));
    },
    credentials: true,
  })
);

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// API routes
app.use("/api", routes);

// Global error handler
app.use(errorHandler);

export default app;
