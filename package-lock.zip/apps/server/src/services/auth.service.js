// apps/server/src/services/auth.service.js
import bcrypt from "bcryptjs";
import User from "../models/User.js"; // ⬅️ Make sure the file is named exactly "User.js"
import { generateToken } from "../utils/jwt.js";

// ------------ AUTH LOGIC ------------

export const signup = async ({ name, email, password, avatar }) => {
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    throw new Error("User already exists");
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    avatar: avatar || "",
  });

  const token = generateToken(user._id.toString());

  // remove password before returning
  const safeUser = user.toObject();
  delete safeUser.password;

  return { user: safeUser, token };
};

export const login = async ({ email, password }) => {
  const user = await User.findOne({ email });
  if (!user) {
    throw new Error("Invalid credentials");
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    throw new Error("Invalid credentials");
  }

  const token = generateToken(user._id.toString());

  const safeUser = user.toObject();
  delete safeUser.password;

  return { user: safeUser, token };
};

export const getUserById = async (userId) => {
  const user = await User.findById(userId).select("-password");
  return user;
};

// ------------ ADMIN HELPERS ------------

export const countUsers = async () => {
  const count = await User.countDocuments();
  return count;
};

export const getAllUsers = async () => {
  const users = await User.find().select("-password");
  return users;
};

export const updateUserRole = async (userId, role) => {
  const user = await User.findByIdAndUpdate(
    userId,
    { role },
    { new: true }
  ).select("-password");

  if (!user) {
    throw new Error("User not found");
  }

  return user;
};

export const deleteUser = async (userId) => {
  const res = await User.findByIdAndDelete(userId);
  if (!res) {
    throw new Error("User not found");
  }
  return true;
};

