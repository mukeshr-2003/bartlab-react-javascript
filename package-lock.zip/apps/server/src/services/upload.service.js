// apps/server/src/services/upload.service.js
import { s3 } from "../config/s3.js";
import { env } from "../config/env.js";
import crypto from "crypto";

export const uploadFile = async (fileBuffer, fileType) => {
  const fileKey = crypto.randomBytes(16).toString("hex");

  const params = {
    Bucket: env.S3_BUCKET,
    Key: `${fileKey}.${fileType}`,
    Body: fileBuffer,
    ContentType: `image/${fileType}`,
    ACL: "public-read",
  };

  const uploaded = await s3.upload(params).promise();

  return {
    url: uploaded.Location,
    key: uploaded.Key,
  };
};
