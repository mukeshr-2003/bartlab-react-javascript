// apps/server/src/services/message.service.js
import Message from "../models/Message.js";
import Chat from "../models/Chat.js";

// Create & save message, update lastMessage on chat
export const sendMessage = async ({ chatId, senderId, text, attachments }) => {
  if (!chatId || !senderId) {
    throw new Error("chatId and senderId are required");
  }

  const message = await Message.create({
    chat: chatId,
    sender: senderId,
    text: text || "",
    attachments: attachments || [],
  });

  // Update last message for the chat
  await Chat.findByIdAndUpdate(chatId, {
    lastMessage: message._id,
  });

  const populated = await message.populate("sender", "name email avatar");
  return populated;
};

// Get messages for a chat
export const getMessagesByChat = async (chatId) => {
  if (!chatId) {
    throw new Error("chatId is required");
  }

  const messages = await Message.find({ chat: chatId })
    .populate("sender", "name email avatar")
    .sort({ createdAt: 1 });

  return messages;
};

// Mark as read for specific or all messages in a chat
export const markMessagesAsRead = async ({ chatId, userId, messageIds }) => {
  if (!chatId || !userId) {
    throw new Error("chatId and userId are required");
  }

  const filter = {
    chat: chatId,
  };

  if (Array.isArray(messageIds) && messageIds.length > 0) {
    filter._id = { $in: messageIds };
  }

  const result = await Message.updateMany(filter, {
    $addToSet: { readBy: userId },
  });

  return { updated: result.modifiedCount };
};

// ------- ADMIN -------
export const countMessages = async () => {
  const count = await Message.countDocuments();
  return count;
};
