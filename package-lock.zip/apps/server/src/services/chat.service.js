// apps/server/src/services/chat.service.js
import Chat from "../models/Chat.js";

// Create or return existing 1-to-1 chat
export const createOrGetOneToOneChat = async (userId, memberId) => {
  // Try to find existing 1-1 chat
  let chat = await Chat.findOne({
    isGroup: false,
    members: { $all: [userId, memberId] },
  })
    .populate("members", "-password")
    .populate("lastMessage");

  if (chat) {
    return chat;
  }

  // Otherwise create a new one
  chat = await Chat.create({
    isGroup: false,
    members: [userId, memberId],
  });

  // Populate before returning
  await chat.populate("members", "-password");
  return chat;
};

// Create a group chat
export const createGroupChat = async ({ name, memberIds, createdBy }) => {
  const chat = await Chat.create({
    name,
    isGroup: true,
    members: [...new Set([...memberIds, createdBy])],
    createdBy,
  });

  await chat.populate("members", "-password");
  return chat;
};

// Get all chats of a user
export const getUserChats = async (userId) => {
  const chats = await Chat.find({
    members: userId,
  })
    .sort({ updatedAt: -1 })
    .populate("members", "-password")
    .populate({
      path: "lastMessage",
      populate: { path: "sender", select: "name email avatar" },
    });

  return chats;
};

// Get specific chat by ID
export const getChatById = async (chatId) => {
  const chat = await Chat.findById(chatId)
    .populate("members", "-password")
    .populate({
      path: "lastMessage",
      populate: { path: "sender", select: "name email avatar" },
    });

  return chat;
};

// Rename group chat
export const renameGroupChat = async (chatId, name) => {
  const chat = await Chat.findByIdAndUpdate(
    chatId,
    { name },
    { new: true }
  ).populate("members", "-password");

  if (!chat) {
    throw new Error("Chat not found");
  }

  return chat;
};

// Add or remove group members
export const updateGroupMembers = async ({ chatId, memberId, action }) => {
  const update =
    action === "add"
      ? { $addToSet: { members: memberId } }
      : { $pull: { members: memberId } };

  const chat = await Chat.findByIdAndUpdate(chatId, update, {
    new: true,
  }).populate("members", "-password");

  if (!chat) {
    throw new Error("Chat not found");
  }

  return chat;
};

// -------- ADMIN --------

export const countChats = async () => {
  const count = await Chat.countDocuments();
  return count;
};
