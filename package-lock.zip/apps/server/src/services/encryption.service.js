// apps/server/src/services/encryption.service.js
import crypto from "crypto";

const algorithm = "aes-256-cbc";
const secretKey = crypto.createHash("sha256").update("supersecurekey").digest();
const ivLength = 16;

export const encrypt = (text) => {
  const iv = crypto.randomBytes(ivLength);
  const cipher = crypto.createCipheriv(algorithm, secretKey, iv);

  let encrypted = cipher.update(text, "utf-8", "hex");
  encrypted += cipher.final("hex");

  return {
    iv: iv.toString("hex"),
    content: encrypted,
  };
};

export const decrypt = ({ iv, content }) => {
  const decipher = crypto.createDecipheriv(
    algorithm,
    secretKey,
    Buffer.from(iv, "hex")
  );

  let decrypted = decipher.update(content, "hex", "utf-8");
  decrypted += decipher.final("utf-8");

  return decrypted;
};
