// apps/server/src/middleware/role.middleware.js
import User from "../models/User.js";
/**
 * Restrict route to specific roles
 * Example: requireRole("admin")
 */
export const requireRole = (role) => {
  return async (req, res, next) => {
    try {
      const user = await User.findById(req.user.id).select("role");

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.role !== role) {
        return res.status(403).json({ message: "Access denied" });
      }

      next();
    } catch (error) {
      return res.status(403).json({ message: "Authorization error" });
    }
  };
};
