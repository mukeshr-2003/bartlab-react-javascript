// apps/server/src/middleware/auth.middleware.js
import { verifyToken } from "../utils/jwt.js";

/**
 * Protect routes: check for JWT
 */
export const auth = (req, res, next) => {
  try {
    const header = req.headers.authorization;

    if (!header) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = header.split(" ")[1];
    if (!token) {
      return res.status(401).json({ message: "Invalid authorization header" });
    }

    const decoded = verifyToken(token);

    if (!decoded || !decoded.id) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    req.user = { id: decoded.id };
    next();
  } catch (error) {
    return res.status(401).json({ message: "Authentication failed" });
  }
};
