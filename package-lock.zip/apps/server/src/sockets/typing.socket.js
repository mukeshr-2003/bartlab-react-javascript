// apps/server/src/sockets/typing.socket.js

const EVENTS = {
  TYPING: "typing:start",
  STOP_TYPING: "typing:stop"
};

export default function typingSocket(io, socket) {
  // When user starts typing
  socket.on(EVENTS.TYPING, ({ chatId, userId }) => {
    if (!chatId || !userId) return;

    socket.to(chatId).emit(EVENTS.TYPING, {
      chatId,
      userId
    });
  });

  // When user stops typing
  socket.on(EVENTS.STOP_TYPING, ({ chatId, userId }) => {
    if (!chatId || !userId) return;

    socket.to(chatId).emit(EVENTS.STOP_TYPING, {
      chatId,
      userId
    });
  });
}
