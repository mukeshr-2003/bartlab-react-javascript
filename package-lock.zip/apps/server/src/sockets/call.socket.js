// apps/server/src/sockets/call.socket.js

const EVENTS = {
  JOIN_CALL: "call:join",
  LEAVE_CALL: "call:leave",
  OFFER: "call:offer",
  ANSWER: "call:answer",
  ICE_CANDIDATE: "call:ice-candidate",
  END_CALL: "call:end"
};

export default function callSocket(io, socket) {
  // User joins a call room (roomId can be chatId or specific callId)
  socket.on(EVENTS.JOIN_CALL, ({ roomId, userId }) => {
    if (!roomId) return;

    socket.join(roomId);
    socket.to(roomId).emit("call:user-joined", { roomId, userId, socketId: socket.id });
  });

  // User leaves the call room
  socket.on(EVENTS.LEAVE_CALL, ({ roomId, userId }) => {
    if (!roomId) return;

    socket.leave(roomId);
    socket.to(roomId).emit("call:user-left", { roomId, userId, socketId: socket.id });
  });

  // WebRTC offer
  socket.on(EVENTS.OFFER, ({ roomId, offer, fromUserId }) => {
    if (!roomId || !offer) return;

    socket.to(roomId).emit(EVENTS.OFFER, {
      roomId,
      offer,
      fromUserId
    });
  });

  // WebRTC answer
  socket.on(EVENTS.ANSWER, ({ roomId, answer, fromUserId }) => {
    if (!roomId || !answer) return;

    socket.to(roomId).emit(EVENTS.ANSWER, {
      roomId,
      answer,
      fromUserId
    });
  });

  // ICE candidate
  socket.on(EVENTS.ICE_CANDIDATE, ({ roomId, candidate, fromUserId }) => {
    if (!roomId || !candidate) return;

    socket.to(roomId).emit(EVENTS.ICE_CANDIDATE, {
      roomId,
      candidate,
      fromUserId
    });
  });

  // End call signal
  socket.on(EVENTS.END_CALL, ({ roomId, userId }) => {
    if (!roomId) return;

    io.to(roomId).emit(EVENTS.END_CALL, {
      roomId,
      userId
    });

    // Optionally: socket.leave(roomId);
  });
}
