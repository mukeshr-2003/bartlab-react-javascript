// apps/server/src/sockets/chat.socket.js
import Chat from "../models/Chat.js";
import Message from "../models/Message.js";

const registerChatHandlers = (io, socket) => {
  const { userId } = socket;

  // Join a chat room
  const handleJoinChat = ({ chatId }) => {
    socket.join(`chat:${chatId}`);
  };

  const handleLeaveChat = ({ chatId }) => {
    socket.leave(`chat:${chatId}`);
  };

  // When a new message is sent (already from REST),
  // we just broadcast it to everyone in the room.
  const handleSendMessage = ({ chatId, message }) => {
    io.to(`chat:${chatId}`).emit("chat:new-message", { chatId, message });
  };

  // ✅ Mark message as delivered by this user
  const handleMessageDelivered = async ({ chatId, messageId }) => {
    try {
      const msg = await Message.findByIdAndUpdate(
        messageId,
        { $addToSet: { deliveredTo: userId } },
        { new: true }
      )
        .populate("sender", "name avatar")
        .lean();

      if (!msg) return;

      io.to(`chat:${chatId}`).emit("message:status-updated", {
        chatId,
        messageId,
        deliveredTo: msg.deliveredTo,
        readBy: msg.readBy,
      });
    } catch (err) {
      console.error("Error in handleMessageDelivered", err.message);
    }
  };

  // ✅ Mark message as read by this user
  const handleMessageRead = async ({ chatId, messageId }) => {
    try {
      const msg = await Message.findByIdAndUpdate(
        messageId,
        { $addToSet: { readBy: userId } },
        { new: true }
      )
        .populate("sender", "name avatar")
        .lean();

      if (!msg) return;

      io.to(`chat:${chatId}`).emit("message:status-updated", {
        chatId,
        messageId,
        deliveredTo: msg.deliveredTo,
        readBy: msg.readBy,
      });
    } catch (err) {
      console.error("Error in handleMessageRead", err.message);
    }
  };

  socket.on("chat:join", handleJoinChat);
  socket.on("chat:leave", handleLeaveChat);
  socket.on("chat:send-message", handleSendMessage);

  // ✅ NEW EVENTS
  socket.on("message:delivered", handleMessageDelivered);
  socket.on("message:read", handleMessageRead);

  socket.on("disconnect", () => {
    // clean up if needed
  });
};

export default registerChatHandlers;
