// apps/server/src/sockets/index.js
import chatSocket from "./chat.socket.js";
import callSocket from "./call.socket.js";
import presenceSocket from "./presence.socket.js";
import typingSocket from "./typing.socket.js";

export default function initSockets(io) {
  console.log("⚡️ Socket.io initialized");

  io.on("connection", (socket) => {
    console.log("🔌 Client connected:", socket.id);

    // Attach handlers for different domains
    chatSocket(io, socket);
    callSocket(io, socket);
    presenceSocket(io, socket);
    typingSocket(io, socket);

    socket.on("disconnect", (reason) => {
      console.log("❌ Client disconnected:", socket.id, "Reason:", reason);
      // Presence socket will handle status updates
      io.emit("user:socket-disconnected", { socketId: socket.id });
    });
  });
}
