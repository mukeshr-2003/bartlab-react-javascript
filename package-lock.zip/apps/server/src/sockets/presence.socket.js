// apps/server/src/sockets/presence.socket.js"

const EVENTS = {
  ONLINE: "user:online",
  OFFLINE: "user:offline",
  STATUS_CHANGE: "user:status-change"
};

// In-memory map of userId -> number of active sockets
// (so that if user has multiple tabs, they only go "offline" when all sockets disconnect)
const onlineUsers = new Map();

export default function presenceSocket(io, socket) {
  let currentUserId = null;

  // Client emits when authenticated / connected
  socket.on(EVENTS.ONLINE, ({ userId }) => {
    if (!userId) return;
    currentUserId = userId;

    const count = onlineUsers.get(userId) || 0;
    onlineUsers.set(userId, count + 1);

    // Broadcast to all others except this socket
    socket.broadcast.emit(EVENTS.STATUS_CHANGE, {
      userId,
      isOnline: true
    });
  });

  // Client can explicitly emit offline (e.g., logout)
  socket.on(EVENTS.OFFLINE, ({ userId }) => {
    if (!userId) return;

    const count = onlineUsers.get(userId) || 0;
    const newCount = Math.max(count - 1, 0);

    if (newCount === 0) {
      onlineUsers.delete(userId);
      socket.broadcast.emit(EVENTS.STATUS_CHANGE, {
        userId,
        isOnline: false
      });
    } else {
      onlineUsers.set(userId, newCount);
    }
  });

  // On disconnect, update presence as well
  socket.on("disconnect", () => {
    if (!currentUserId) return;

    const count = onlineUsers.get(currentUserId) || 0;
    const newCount = Math.max(count - 1, 0);

    if (newCount === 0) {
      onlineUsers.delete(currentUserId);
      socket.broadcast.emit(EVENTS.STATUS_CHANGE, {
        userId: currentUserId,
        isOnline: false
      });
    } else {
      onlineUsers.set(currentUserId, newCount);
    }
  });
}
