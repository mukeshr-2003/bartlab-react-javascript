// apps/server/src/routes/message.routes.js
import express from "express";
import * as messageController from "../controllers/message.controller.js";
import { auth } from "../middleware/auth.middleware.js";

const router = express.Router();

// All message routes are protected
router.use(auth);

// Send a message
// POST /api/messages
router.post("/", messageController.sendMessage);

// Get messages for a chat
// GET /api/messages/:chatId
router.get("/:chatId", messageController.getMessagesByChat);

// Mark messages as read
// POST /api/messages/:chatId/read
router.post("/:chatId/read", messageController.markMessagesAsRead);

export default router;
