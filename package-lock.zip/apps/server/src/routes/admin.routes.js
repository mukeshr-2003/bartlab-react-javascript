// apps/server/src/routes/admin.routes.js
import express from "express";
import * as adminController from "../controllers/admin.controller.js";
import { auth } from "../middleware/auth.middleware.js";
import { requireRole } from "../middleware/role.middleware.js";

const router = express.Router();

// All admin routes: require auth + admin role
router.use(auth);
router.use(requireRole("admin"));

// Dashboard stats
// GET /api/admin/stats
router.get("/stats", adminController.getDashboardStats);

// All users
// GET /api/admin/users
router.get("/users", adminController.getAllUsers);

// Update user role
// PATCH /api/admin/users/:userId/role
router.patch("/users/:userId/role", adminController.updateUserRole);

// Delete user
// DELETE /api/admin/users/:userId
router.delete("/users/:userId", adminController.deleteUser);

export default router;
