// apps/server/src/routes/index.js
import express from "express";
import authRoutes from "./auth.routes.js";
import chatRoutes from "./chat.routes.js";
import messageRoutes from "./message.routes.js";
import adminRoutes from "./admin.routes.js";

const router = express.Router();

router.use("/auth", authRoutes);
router.use("/chats", chatRoutes);
router.use("/messages", messageRoutes);
router.use("/admin", adminRoutes);

export default router;
