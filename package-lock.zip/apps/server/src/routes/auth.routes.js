// apps/server/src/routes/auth.routes.js
import express from "express";
import * as authController from "../controllers/auth.controller.js";
import { auth } from "../middleware/auth.middleware.js";

const router = express.Router();

// Public
router.post("/signup", authController.signup);
router.post("/login", authController.login);

// Protected
router.get("/me", auth, authController.getMe);

export default router;
