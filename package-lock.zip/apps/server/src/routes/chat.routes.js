// apps/server/src/routes/chat.routes.js
import express from "express";
import * as chatController from "../controllers/chat.controller.js";
import { auth } from "../middleware/auth.middleware.js";

const router = express.Router();

// All chat routes are protected
router.use(auth);

// 1-1 chat: create or fetch existing
// POST /api/chats
router.post("/", chatController.createOrGetOneToOneChat);

// Group chat: create
// POST /api/chats/group
router.post("/group", chatController.createGroupChat);

// Get all my chats
// GET /api/chats
router.get("/", chatController.getMyChats);

// Get specific chat by id
// GET /api/chats/:chatId
router.get("/:chatId", chatController.getChatById);

// Rename group chat
// PATCH /api/chats/:chatId/name
router.patch("/:chatId/name", chatController.renameGroupChat);

// Add/remove group members
// PATCH /api/chats/:chatId/members
router.patch("/:chatId/members", chatController.updateGroupMembers);

export default router;
