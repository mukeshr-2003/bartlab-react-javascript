// apps/server/src/config/s3.js
import AWS from "aws-sdk";
import { env } from "./env.js";

if (!env.S3_REGION || !env.AWS_ACCESS_KEY_ID || !env.AWS_SECRET_ACCESS_KEY) {
  console.warn("⚠️ S3 config is incomplete. Uploads may not work until you set env vars.");
}

AWS.config.update({
  region: env.S3_REGION,
  accessKeyId: env.AWS_ACCESS_KEY_ID,
  secretAccessKey: env.AWS_SECRET_ACCESS_KEY
});

export const s3 = new AWS.S3();

