// apps/server/src/controllers/auth.controller.js
import * as authService from "../services/auth.service.js";

/**
 * POST /api/auth/signup
 */
export const signup = async (req, res, next) => {
  try {
    const { name, email, password, avatar } = req.body;

    const result = await authService.signup({
      name,
      email,
      password,
      avatar,
    });

    return res.status(201).json({
      message: "User registered successfully",
      user: result.user,
      token: result.token,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/auth/login
 */
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const result = await authService.login({ email, password });

    return res.status(200).json({
      message: "Login successful",
      user: result.user,
      token: result.token,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/auth/me
 * Requires auth.middleware to set req.user
 */
export const getMe = async (req, res, next) => {
  try {
    const user = await authService.getUserById(req.user.id);
    return res.status(200).json({ user });
  } catch (error) {
    next(error);
  }
};

