// apps/server/src/controllers/message.controller.js
import * as messageService from "../services/message.service.js";

/**
 * POST /api/messages
 * Body: { chatId, text, attachments? }
 */
export const sendMessage = async (req, res, next) => {
  try {
    const senderId = req.user.id;
    const { chatId, text, attachments } = req.body;

    const message = await messageService.sendMessage({
      chatId,
      senderId,
      text,
      attachments,
    });

    return res.status(201).json({
      message: "Message sent",
      data: message,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/messages/:chatId
 */
export const getMessagesByChat = async (req, res, next) => {
  try {
    const { chatId } = req.params;

    const messages = await messageService.getMessagesByChat(chatId);

    return res.status(200).json({ messages });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/messages/:chatId/read
 * Body: { messageIds?: [] } or mark all as read
 */
export const markMessagesAsRead = async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const userId = req.user.id;
    const { messageIds } = req.body;

    const result = await messageService.markMessagesAsRead({
      chatId,
      userId,
      messageIds,
    });

    return res.status(200).json({
      message: "Messages marked as read",
      ...result,
    });
  } catch (error) {
    next(error);
  }
};

