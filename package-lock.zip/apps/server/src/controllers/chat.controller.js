// apps/server/src/controllers/chat.controller.js
import * as chatService from "../services/chat.service.js";

/**
 * POST /api/chats
 * Body: { memberId } for 1-1 chat
 */
export const createOrGetOneToOneChat = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { memberId } = req.body;

    const chat = await chatService.createOrGetOneToOneChat(userId, memberId);

    return res.status(200).json({
      message: "Chat fetched/created successfully",
      chat,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/chats/group
 * Body: { name, memberIds: [] }
 */
export const createGroupChat = async (req, res, next) => {
  try {
    const { name, memberIds } = req.body;
    const createdBy = req.user.id;

    const chat = await chatService.createGroupChat({
      name,
      memberIds,
      createdBy,
    });

    return res.status(201).json({
      message: "Group chat created successfully",
      chat,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/chats
 * Get all chats of logged-in user
 */
export const getMyChats = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const chats = await chatService.getUserChats(userId);

    return res.status(200).json({ chats });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/chats/:chatId
 */
export const getChatById = async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const chat = await chatService.getChatById(chatId);

    if (!chat) {
      return res.status(404).json({ message: "Chat not found" });
    }

    return res.status(200).json({ chat });
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /api/chats/:chatId/name
 * Body: { name }
 */
export const renameGroupChat = async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const { name } = req.body;

    const chat = await chatService.renameGroupChat(chatId, name);

    return res.status(200).json({
      message: "Group name updated",
      chat,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /api/chats/:chatId/members
 * Body: { memberId, action: "add" | "remove" }
 */
export const updateGroupMembers = async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const { memberId, action } = req.body;

    const chat = await chatService.updateGroupMembers({
      chatId,
      memberId,
      action,
    });

    return res.status(200).json({
      message: "Group members updated",
      chat,
    });
  } catch (error) {
    next(error);
  }
};

