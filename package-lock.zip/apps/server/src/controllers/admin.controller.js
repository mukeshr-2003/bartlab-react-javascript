// apps/server/src/controllers/admin.controller.js
import * as authService from "../services/auth.service.js";
import * as chatService from "../services/chat.service.js";
import * as messageService from "../services/message.service.js";

/**
 * GET /api/admin/stats
 * Requires admin role
 */
export const getDashboardStats = async (req, res, next) => {
  try {
    const stats = await Promise.all([
      authService.countUsers(),
      chatService.countChats(),
      messageService.countMessages(),
    ]);

    const [userCount, chatCount, messageCount] = stats;

    return res.status(200).json({
      userCount,
      chatCount,
      messageCount,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/admin/users
 */
export const getAllUsers = async (req, res, next) => {
  try {
    const users = await authService.getAllUsers();
    return res.status(200).json({ users });
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /api/admin/users/:userId/role
 * Body: { role: "user" | "admin" }
 */
export const updateUserRole = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    const user = await authService.updateUserRole(userId, role);

    return res.status(200).json({
      message: "User role updated",
      user,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/admin/users/:userId
 */
export const deleteUser = async (req, res, next) => {
  try {
    const { userId } = req.params;

    await authService.deleteUser(userId);

    return res.status(200).json({
      message: "User deleted",
    });
  } catch (error) {
    next(error);
  }
};
