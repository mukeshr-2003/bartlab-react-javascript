// apps/server/src/models/Message.js
import mongoose from "mongoose";

const { Schema, Types } = mongoose;

const messageSchema = new Schema(
  {
    chat: { type: Types.ObjectId, ref: "Chat", required: true },
    sender: { type: Types.ObjectId, ref: "User", required: true },

    text: { type: String, default: "" },

    attachments: [
      {
        url: String,
        type: String,
        name: String,
        size: Number,
      },
    ],

    // ✅ Already existed in earlier version, keep it
    readBy: [
      {
        type: Types.ObjectId,
        ref: "User",
      },
    ],

    // ✅ NEW: track who has at least RECEIVED the message
    deliveredTo: [
      {
        type: Types.ObjectId,
        ref: "User",
      },
    ],
  },
  { timestamps: true }
);

const Message = mongoose.model("Message", messageSchema);
export default Message;
