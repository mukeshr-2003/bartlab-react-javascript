// apps/server/src/models/Chat.js
import mongoose from "mongoose";

const chatSchema = new mongoose.Schema(
  {
    name: {
      type: String,          // for group chats
      trim: true
    },

    isGroup: {
      type: Boolean,
      default: false
    },

    members: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
      }
    ],

    lastMessage: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message",
      default: null
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

const Chat = mongoose.model("Chat", chatSchema);
export default Chat;
