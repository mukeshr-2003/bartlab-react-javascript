// apps/server/src/models/CallSession.js
import mongoose from "mongoose";

const callSessionSchema = new mongoose.Schema(
  {
    participants: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
      }
    ],

    chat: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Chat",
      default: null // optional: linked to a chat
    },

    startedAt: {
      type: Date,
      default: Date.now
    },

    endedAt: {
      type: Date,
      default: null
    },

    status: {
      type: String,
      enum: ["ongoing", "ended", "missed"],
      default: "ongoing"
    },

    type: {
      type: String,
      enum: ["audio", "video"],
      default: "video"
    }
  },
  {
    timestamps: true
  }
);

const CallSession = mongoose.model("CallSession", callSessionSchema);
export default CallSession;
