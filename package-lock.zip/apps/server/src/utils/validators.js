// apps/server/src/utils/validators.js
import { AppError } from "./error.js";

export const validateSignupPayload = (body) => {
  const { name, email, password } = body;

  if (!name || !email || !password) {
    throw new AppError("Name, email and password are required", 400);
  }

  if (!email.includes("@")) {
    throw new AppError("Invalid email format", 400);
  }

  if (password.length < 6) {
    throw new AppError("Password must be at least 6 characters", 400);
  }
};

export const validateLoginPayload = (body) => {
  const { email, password } = body;

  if (!email || !password) {
    throw new AppError("Email and password are required", 400);
  }
};

export const validateCreateChatPayload = (body) => {
  const { memberId } = body;

  if (!memberId) {
    throw new AppError("memberId is required", 400);
  }
};

export const validateSendMessagePayload = (body) => {
  const { chatId, text, attachments } = body;

  if (!chatId) {
    throw new AppError("chatId is required", 400);
  }

  if (!text && (!attachments || attachments.length === 0)) {
    throw new AppError("Message text or attachments are required", 400);
  }
};
