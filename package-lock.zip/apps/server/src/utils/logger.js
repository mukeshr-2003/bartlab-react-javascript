// apps/server/src/utils/logger.js

export const info = (...args) => {
  console.log("ℹ️ [INFO]:", ...args);
};

export const warn = (...args) => {
  console.warn("⚠️ [WARN]:", ...args);
};

export const error = (...args) => {
  console.error("❌ [ERROR]:", ...args);
};

export default {
  info,
  warn,
  error,
};
