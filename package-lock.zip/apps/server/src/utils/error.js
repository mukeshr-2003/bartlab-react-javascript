// apps/server/src/utils/error.js
import { error as logError } from "./logger.js";

export class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.statusCode = statusCode;
  }
}

/**
 * Express global error handler
 * Use as: app.use(errorHandler);
 */
export const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;

  logError(err.message, err.stack);

  // You can customize error response shape here
  res.status(statusCode).json({
    message: err.message || "Internal Server Error",
  });
};
