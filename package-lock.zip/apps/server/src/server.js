// apps/server/src/server.js
import { createServer } from "http";
import { Server } from "socket.io";
import app from "./app.js";
import { connectDB } from "./config/db.js";
import { env } from "./config/env.js";
import initSockets from "./sockets/index.js";

const startServer = async () => {
  try {
    await connectDB();

    const httpServer = createServer(app);

    const io = new Server(httpServer, {
      cors: {
        origin: [env.CLIENT_URL, env.ADMIN_URL],
        methods: ["GET", "POST", "PATCH", "DELETE"],
      },
    });

    // Initialize all socket handlers
    initSockets(io);

    httpServer.listen(env.PORT, () => {
      console.log(`🚀 Server running on port ${env.PORT}`);
    });
  } catch (error) {
    console.error("❌ Failed to start server:", error.message);
    process.exit(1);
  }
};

startServer();
