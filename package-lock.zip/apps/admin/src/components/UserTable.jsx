// apps/admin/src/components/UserTable.jsx
import React from "react";

const UserTable = ({ users, onRoleChange, onDelete }) => {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Joined</th>
          <th />
        </tr>
      </thead>
      <tbody>
        {users.map((u) => (
          <tr key={u._id}>
            <td>{u.name}</td>
            <td>{u.email}</td>
            <td>{u.role}</td>
            <td>{new Date(u.createdAt).toLocaleDateString()}</td>
            <td>
              <button
                className="btn-outline"
                onClick={() =>
                  onRoleChange(u._id, u.role === "admin" ? "user" : "admin")
                }
              >
                {u.role === "admin" ? "Make User" : "Make Admin"}
              </button>{" "}
              <button
                className="btn-outline"
                onClick={() => onDelete(u._id)}
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
        {users.length === 0 && (
          <tr>
            <td colSpan={5}>No users found.</td>
          </tr>
        )}
      </tbody>
    </table>
  );
};

export default UserTable;
