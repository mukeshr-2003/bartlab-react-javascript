// apps/admin/src/components/AnalyticsCharts.jsx
import React from "react";

const AnalyticsCharts = ({ stats }) => {
  return (
    <div className="card">
      <div className="card-title">Activity Overview</div>
      <p style={{ fontSize: "0.85rem", color: "#9ca3af" }}>
        Users: {stats.userCount} | Chats: {stats.chatCount} | Messages:{" "}
        {stats.messageCount}
      </p>
      <p style={{ fontSize: "0.78rem", color: "#6b7280" }}>
        You can integrate real charts (Recharts, Chart.js) here later.
      </p>
    </div>
  );
};

export default AnalyticsCharts;
