// apps/admin/src/components/Sidebar.jsx
import React from "react";
import { NavLink } from "react-router-dom";

const Sidebar = () => {
  const linkClass = ({ isActive }) =>
    "sidebar-link" + (isActive ? " sidebar-link--active" : "");

  return (
    <aside className="sidebar">
      <div className="sidebar-title">Admin Panel</div>
      <nav className="sidebar-nav">
        <NavLink className={linkClass} to="/dashboard">
          Dashboard
        </NavLink>
        <NavLink className={linkClass} to="/users">
          Users
        </NavLink>
        <NavLink className={linkClass} to="/chats">
          Chats
        </NavLink>
        <NavLink className={linkClass} to="/reports">
          Reports
        </NavLink>
      </nav>
    </aside>
  );
};

export default Sidebar;
