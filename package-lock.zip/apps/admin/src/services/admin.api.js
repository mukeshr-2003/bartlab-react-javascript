// apps/admin/src/services/admin.api.js
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_URL,
});

// Optionally, add admin token header here if separate auth is used.

export const getStatsApi = async () => {
  const res = await api.get("/admin/stats");
  return res.data;
};

export const getUsersApi = async () => {
  const res = await api.get("/admin/users");
  return res.data.users;
};

export const updateUserRoleApi = async (userId, role) => {
  const res = await api.patch(`/admin/users/${userId}/role`, { role });
  return res.data.user;
};

export const deleteUserApi = async (userId) => {
  const res = await api.delete(`/admin/users/${userId}`);
  return res.data;
};
