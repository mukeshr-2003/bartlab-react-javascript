// apps/admin/src/App.jsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/Sidebar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import UserManagement from "./pages/UserManagement.jsx";
import ChatsOverview from "./pages/ChatsOverview.jsx";
import Reports from "./pages/Reports.jsx";

const App = () => {
  return (
    <div className="admin-root">
      <Sidebar />
      <main className="admin-main">
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/chats" element={<ChatsOverview />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="*" element={<div>404 | Not Found</div>} />
        </Routes>
      </main>
    </div>
  );
};

export default App;
