// apps/admin/src/pages/ChatsOverview.jsx
import React from "react";

const ChatsOverview = () => {
  return (
    <div>
      <h1 className="page-title">Chats Overview</h1>
      <div className="card">
        <p style={{ fontSize: "0.85rem", color: "#9ca3af" }}>
          Here you can later show:
        </p>
        <ul style={{ fontSize: "0.85rem", color: "#9ca3af" }}>
          <li>Top active chats</li>
          <li>Recent group creations</li>
          <li>Most active users</li>
        </ul>
        <p style={{ fontSize: "0.78rem", color: "#6b7280" }}>
          For now, this is a placeholder page. You can integrate charts or
          tables based on your project needs.
        </p>
      </div>
    </div>
  );
};

export default ChatsOverview;
