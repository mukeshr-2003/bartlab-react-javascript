// apps/admin/src/pages/Reports.jsx
import React from "react";

const Reports = () => {
  return (
    <div>
      <h1 className="page-title">Reports</h1>
      <div className="card">
        <p style={{ fontSize: "0.85rem", color: "#9ca3af" }}>
          Placeholder for moderation / logs / analytics exports.
        </p>
        <p style={{ fontSize: "0.8rem", color: "#6b7280" }}>
          You can add:
        </p>
        <ul style={{ fontSize: "0.8rem", color: "#6b7280" }}>
          <li>Daily / weekly usage reports</li>
          <li>Suspicious behavior logs</li>
          <li>CSV exports</li>
        </ul>
      </div>
    </div>
  );
};

export default Reports;
