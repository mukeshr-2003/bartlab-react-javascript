// apps/admin/src/pages/UserManagement.jsx
import React, { useEffect, useState } from "react";
import {
  getUsersApi,
  updateUserRoleApi,
  deleteUserApi,
} from "../services/admin.api.js";
import UserTable from "../components/UserTable.jsx";

const UserManagement = () => {
  const [users, setUsers] = useState([]);

  const loadUsers = async () => {
    const list = await getUsersApi();
    setUsers(list);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleRoleChange = async (userId, role) => {
    await updateUserRoleApi(userId, role);
    await loadUsers();
  };

  const handleDelete = async (userId) => {
    await deleteUserApi(userId);
    await loadUsers();
  };

  return (
    <div>
      <h1 className="page-title">User Management</h1>
      <div className="card">
        <UserTable
          users={users}
          onRoleChange={handleRoleChange}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
};

export default UserManagement;
