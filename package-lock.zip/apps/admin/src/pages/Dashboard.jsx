// apps/admin/src/pages/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { getStatsApi } from "../services/admin.api.js";
import AnalyticsCharts from "../components/AnalyticsCharts.jsx";

const Dashboard = () => {
  const [stats, setStats] = useState({
    userCount: 0,
    chatCount: 0,
    messageCount: 0,
  });

  useEffect(() => {
    (async () => {
      try {
        const data = await getStatsApi();
        setStats(data);
      } catch (err) {
        console.error("Failed to load stats", err);
      }
    })();
  }, []);

  return (
    <div>
      <h1 className="page-title">Dashboard</h1>
      <div className="admin-grid">
        <div className="card">
          <div className="card-title">Users</div>
          <div className="card-value">{stats.userCount}</div>
        </div>
        <div className="card">
          <div className="card-title">Chats</div>
          <div className="card-value">{stats.chatCount}</div>
        </div>
        <div className="card">
          <div className="card-title">Messages</div>
          <div className="card-value">{stats.messageCount}</div>
        </div>
      </div>
      <div style={{ marginTop: "1rem" }}>
        <AnalyticsCharts stats={stats} />
      </div>
    </div>
  );
};

export default Dashboard;
