// packages/common/types/chat.types.js

/**
 * @typedef {Object} ChatMember
 * @property {string} _id
 * @property {string} name
 * @property {string} email
 * @property {string} [avatar]
 */

/**
 * @typedef {Object} Chat
 * @property {string} _id
 * @property {string} [name]
 * @property {boolean} isGroup
 * @property {ChatMember[]} members
 * @property {string} createdAt
 * @property {string} updatedAt
 */

export {};
