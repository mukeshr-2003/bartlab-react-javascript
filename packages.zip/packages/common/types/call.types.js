// packages/common/types/call.types.js

/**
 * @typedef {Object} CallParticipant
 * @property {string} _id
 * @property {string} name
 */

/**
 * @typedef {Object} CallSession
 * @property {string} _id
 * @property {CallParticipant[]} participants
 * @property {string} [chat]
 * @property {string} startedAt
 * @property {string} [endedAt]
 * @property {"ongoing" | "ended" | "missed"} status
 * @property {"audio" | "video"} type
 * @property {string} createdAt
 * @property {string} updatedAt
 */

export {};
