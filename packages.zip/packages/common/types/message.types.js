// packages/common/types/message.types.js

/**
 * @typedef {Object} MessageAttachment
 * @property {string} url
 * @property {string} [type]
 * @property {string} [name]
 * @property {number} [size]
 */

/**
 * @typedef {Object} MessageSender
 * @property {string} _id
 * @property {string} name
 * @property {string} [avatar]
 */

/**
 * @typedef {Object} Message
 * @property {string} _id
 * @property {string} chat
 * @property {MessageSender} sender
 * @property {string} [text]
 * @property {MessageAttachment[]} [attachments]
 * @property {string[]} [readBy]
 * @property {boolean} [isDeleted]
 * @property {string} createdAt
 * @property {string} updatedAt
 */

export {};
