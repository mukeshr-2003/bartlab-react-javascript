// packages/common/utils/constants.js

export const SOCKET_EVENTS = {
  CONNECTION: "connection",
  DISCONNECT: "disconnect",
  JOIN_CHAT: "chat:join",
  LEAVE_CHAT: "chat:leave",
  SEND_MESSAGE: "chat:send-message",
  NEW_MESSAGE: "chat:new-message",

  TYPING_START: "typing:start",
  TYPING_STOP: "typing:stop",

  USER_ONLINE: "user:online",
  USER_OFFLINE: "user:offline",
  USER_STATUS_CHANGE: "user:status-change",

  CALL_JOIN: "call:join",
  CALL_LEAVE: "call:leave",
  CALL_OFFER: "call:offer",
  CALL_ANSWER: "call:answer",
  CALL_ICE: "call:ice-candidate",
  CALL_END: "call:end",
};
