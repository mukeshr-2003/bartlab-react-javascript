// packages/common/utils/formatDate.js
export const formatShortDateTime = (date) => {
  const d = new Date(date);
  return d.toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const formatDateOnly = (date) => {
  const d = new Date(date);
  return d.toLocaleDateString();
};
